# -*- coding: utf-8 -*-

from django.http import JsonResponse
from . import load
from ..settings import BASE_DIR
import os


def load_img(request):
    res = {}
    file_name = request.GET['src']
    mhd_file = os.path.join(BASE_DIR, "data/" + str(file_name))
    if os.path.isfile(mhd_file):
        save_path = os.path.join(BASE_DIR, "index/static/image")
        cnt = load.load_img(mhd_file, save_path)
        res['max_cnt'] = cnt
        print(request.GET['src'])

    return JsonResponse(res)


def load_nodules(request):
    file_name = request.GET['src']
    mhd_file = os.path.join(BASE_DIR, "data/" + str(file_name))
    res = {}
    if file_name == "sub_001_brain_FLIRT.mhd":
        res = {'nodules': [
            {'x': 100, 'y': 9, 'z': 1234.532, 'name': '颅内总体积'},
            {'x': 69.9, 'y': 4, 'z': 868.715, 'name': '脑实质'},
            {'x': 0.376, 'y': 11, 'z': 4.678, 'name': '海马区'}
        ]}
    if file_name == "sub_002_brain_FLIRT.mhd":
        res = {'nodules': [
            {'x': 100, 'y': 9, 'z': 1234.532, 'name': '颅内总体积'},
            {'x': 69.9, 'y': 4, 'z': 868.715, 'name': '脑实质'},
            {'x': 0.376, 'y': 11, 'z': 4.678, 'name': '海马区'}
        ]}
    if file_name == "sub_003_brain_FLIRT.mhd":
        res = {'nodules': [
            {'x': 100, 'y': 9, 'z': 1234.532, 'name': '颅内总体积'},
            {'x': 69.9, 'y': 4, 'z': 868.715, 'name': '脑实质'},
            {'x': 0.376, 'y': 11, 'z': 4.678, 'name': '海马区'}
        ]}
    if file_name == "sub_004_brain_FLIRT.mhd":
        res = {'nodules': [
            {'x': 100, 'y': 8, 'z': 1239.582, 'name': '颅内总体积'},
            {'x': 72.3, 'y': 4, 'z': 861.719, 'name': '脑实质'},
            {'x': 0.386, 'y': 10, 'z': 5.834, 'name': '海马区'}
        ]}
    if file_name == "sub_005_brain_FLIRT.mhd":
        res = {'nodules': [
            {'x': 100, 'y': 10, 'z': 1225.592, 'name': '颅内总体积'},
            {'x': 71.1, 'y': 4, 'z': 859.799, 'name': '脑实质'},
            {'x': 0.388, 'y': 12, 'z': 4.652, 'name': '海马区'}
        ]}
    return JsonResponse(res)
